jQuery(document).ready(function ($) {

    // $("#propbar-button-header").on('click', function () {
    //     var propbar_target = $(this).data('target');
    //     $(this).toggleClass('collapsed');
    //     $(propbar_target).toggleClass('show');
    //     $('.propbar-toggler-icon').toggleClass('hide');
    //     $('.bropbar-close-icon').toggleClass('show');
    // });
    //
    // $("#propbar-button-footer").on('click', function () {
    //     var propbar_target = $(this).data('target');
    //     $(this).toggleClass('collapsed');
    //     $(propbar_target).toggleClass('show');
    //     $('.propbar-footer-toggler-icon').toggleClass('hide');
    //     $('.propbar-footer-close-icon').toggleClass('show');
    // });


    $('#next-btn').on('click', function() {
        nextSlide();
    });

    $('#prev-btn').on('click', function() {
        prevSlide();
    });

    $('#next-btn-footer').on('click', function() {
        nextSlideFooter();
    });

    $('#prev-btn-footer').on('click', function() {
        prevSlideFooter();
    });

    var slideNow = 1;
    var slideCount = $('#propbar_header').children().length;
    var slideNowFooter = 1;
    var slideCountFooter = $('#propbar_footer').children().length;

    function nextSlide() {

        if (slideNow == slideCount || slideNow > slideCount) {
            $('#propbar_header').css('transform', 'translate(0, 0)');
            slideNow = 1;
            $('#prev-btn').hide();
        } else {
            // translateWidth = -$('#viewport').width() * (slideNow);
            var translateWidth = 150*slideNow;
            $('#propbar_header').css({
                'transform': 'translate(-' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(-' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(-' + translateWidth + 'px, 0)'
            });
            slideNow++;
            if(slideNow<0){slideNow = 0;}
            $('#prev-btn').show();
        }
    }

    function prevSlide() {

        var translateWidth = 150*(slideNow - 2);
        $('#propbar_header').css({
            'transform': 'translate(-' + translateWidth + 'px, 0)',
            '-webkit-transform': 'translate(-' + translateWidth + 'px, 0)',
            '-ms-transform': 'translate(-' + translateWidth + 'px, 0)',
        });
        slideNow--;
        if(slideNow<0 || slideNow===0){
            slideNow = 1;
            $('#prev-btn').hide();
        }

    }

    function nextSlideFooter() {

        if (slideNowFooter == slideCountFooter || slideNowFooter > slideCountFooter) {
            $('#propbar_footer').css('transform', 'translate(0, 0)');
            slideNowFooter = 1;
            $('#prev-btn-footer').hide();
        } else {
            // translateWidth = -$('#viewport').width() * (slideNow);
            var translateWidth = 150*slideNowFooter;
            $('#propbar_footer').css({
                'transform': 'translate(-' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(-' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(-' + translateWidth + 'px, 0)'
            });
            slideNowFooter++;
            if(slideNowFooter<0){slideNowFooter = 0;}
            $('#prev-btn-footer').show();
        }
    }

    function prevSlideFooter() {

        var translateWidth = 150 * (slideNowFooter - 2);
        $('#propbar_footer').css({
            'transform': 'translate(-' + translateWidth + 'px, 0)',
            '-webkit-transform': 'translate(-' + translateWidth + 'px, 0)',
            '-ms-transform': 'translate(-' + translateWidth + 'px, 0)',
        });
        slideNowFooter--;
        if (slideNowFooter < 0 || slideNowFooter === 0) {
            slideNowFooter = 1;
            $('#prev-btn-footer').hide();
        }
    }
});


