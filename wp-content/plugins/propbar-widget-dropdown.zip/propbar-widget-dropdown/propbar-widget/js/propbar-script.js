jQuery(document).ready(function ($) {

    $("#propbar-button-header").on('click', function () {
        var propbar_target = $(this).data('target');
        $(this).toggleClass('collapsed');
        $(propbar_target).toggleClass('show');
        $('.propbar-toggler-icon').toggleClass('hide');
        $('.bropbar-close-icon').toggleClass('show');
    });

    $("#propbar-button-footer").on('click', function () {
        var propbar_target = $(this).data('target');
        $(this).toggleClass('collapsed');
        $(propbar_target).toggleClass('show');
        $('.propbar-footer-toggler-icon').toggleClass('hide');
        $('.propbar-footer-close-icon').toggleClass('show');
    });

});


